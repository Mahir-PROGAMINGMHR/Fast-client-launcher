package com.fastclient.launcher

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Theme: change these colors to match your Fast Client look
val Bg = Color(0xFF0D0F14); val Card = Color(0xFF171A22); val Accent = Color(0xFF00E5FF); val Muted = Color(0xFF8A90A0)

enum class AccountType(val label: String) { LOCAL("Local"), MICROSOFT("Microsoft"), ELYBY("Ely.by") }
data class Account(val type: AccountType, val name: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) { App() } }
    }
}

@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    var account by remember { mutableStateOf<Account?>(null) }
    val tabs = listOf("Home" to Icons.Default.PlayArrow, "Accounts" to Icons.Default.Person, "Skins" to Icons.Default.Face, "Settings" to Icons.Default.Settings)
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            tabs.forEachIndexed { i, (n, ic) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, n) }, label = { Text(n) })
            }
        }
    }) { p ->
        Box(Modifier.padding(p).fillMaxSize().padding(16.dp)) {
            when (tab) {
                0 -> Home(account) { tab = 1 }
                1 -> Accounts(account) { account = it }
                2 -> Skins()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun Home(account: Account?, goAccounts: () -> Unit) {
    var version by remember { mutableStateOf("1.8.9") }
    val versions = listOf("1.8.9", "1.12.2", "1.16.5", "1.20.1", "1.21")
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("FAST CLIENT", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Accent)
        Text("Launcher", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Account", color = Muted)
                Text(account?.let { "${it.name} (${it.type.label})" } ?: "Not logged in", fontWeight = FontWeight.Bold)
                if (account == null) TextButton(onClick = goAccounts) { Text("Login") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Version", color = Muted)
                Box {
                    OutlinedButton(onClick = { open = true }) { Text("Fast Client $version") }
                    DropdownMenu(open, { open = false }) {
                        versions.forEach { v -> DropdownMenuItem(text = { Text(v) }, onClick = { version = v; open = false }) }
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = { /* TODO: hook game runtime here */ }, enabled = account != null,
            modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(14.dp)) {
            Text("PLAY", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

@Composable
fun Accounts(current: Account?, onLogin: (Account?) -> Unit) {
    var type by remember { mutableStateOf(AccountType.LOCAL) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Accounts", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AccountType.values().forEach { t -> FilterChip(type == t, { type = t }, { Text(t.label) }) }
        }
        when (type) {
            AccountType.LOCAL -> {
                Text("Offline account: only a username is needed.", color = Muted)
                OutlinedTextField(user, { user = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { if (user.isNotBlank()) onLogin(Account(type, user.trim())) }) { Text("Add local account") }
            }
            AccountType.MICROSOFT -> {
                Text("Opens the Microsoft sign-in page. You need an Azure app Client ID (TODO in code).", color = Muted)
                Button(onClick = { /* TODO: MSAL / device-code flow */ }) { Text("Sign in with Microsoft") }
            }
            AccountType.ELYBY -> {
                Text("Ely.by login (authserver.ely.by).", color = Muted)
                OutlinedTextField(user, { user = it }, label = { Text("Username or email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { /* TODO: POST https://authserver.ely.by/auth/authenticate */ if (user.isNotBlank()) onLogin(Account(type, user.trim())) }) { Text("Login with Ely.by") }
            }
        }
        if (current != null) {
            HorizontalDivider()
            Text("Logged in: ${current.name} (${current.type.label})")
            TextButton(onClick = { onLogin(null) }) { Text("Logout") }
        }
    }
}

@Composable
fun Skins() {
    val ctx = LocalContext.current
    var bitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bmp != null && bmp.width == 64 && (bmp.height == 64 || bmp.height == 32)) { bitmap = bmp; error = null }
        else error = "Skin must be a 64x64 or 64x32 PNG."
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("Skins", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.size(200.dp).background(Card, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            val b = bitmap
            if (b != null) Image(b.asImageBitmap(), "Skin preview", Modifier.fillMaxSize().padding(8.dp), filterQuality = FilterQuality.None)
            else Text("No skin selected", color = Muted)
        }
        error?.let { Text(it, color = Color(0xFFFF6B6B)) }
        Button(onClick = { picker.launch("image/png") }) { Text("Upload skin") }
        Button(onClick = { /* TODO: send skin to account's skin API */ }, enabled = bitmap != null) { Text("Apply skin") }
    }
}

@Composable
fun SettingsScreen() {
    var ram by remember { mutableStateOf(2f) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("RAM: ${ram.toInt()} GB", color = Muted)
        Slider(ram, { ram = it }, valueRange = 1f..6f, steps = 4)
    }
}
